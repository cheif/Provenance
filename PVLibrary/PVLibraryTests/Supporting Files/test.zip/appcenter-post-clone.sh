#!/usr/bin/env bash

git submodule update --recursive --init
#make setup